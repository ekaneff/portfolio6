@extends('layouts.master')

@section('content')
	<h1>serving from mainpage.two</h1>
@endsection
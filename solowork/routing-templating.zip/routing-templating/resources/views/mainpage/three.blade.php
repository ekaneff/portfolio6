@extends('layouts.master')

@section('content')
	<h1>serving from mainpage.three</h1>
@endsection
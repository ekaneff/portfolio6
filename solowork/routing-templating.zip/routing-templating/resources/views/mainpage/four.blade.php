@extends('layouts.master')

@section('content')
	<h1>serving from MainpageController @ index</h1>
@endsection
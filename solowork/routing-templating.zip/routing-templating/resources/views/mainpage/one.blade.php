@extends('mainpage.index')

@section('content')
<h1>serving from mainpage.one</h1>
@endsection
@extends('layouts.master')

@section('title')
	The Bike Shop | Order History
@endsection

@include('partials.nav')

<h1>Order History</h1>
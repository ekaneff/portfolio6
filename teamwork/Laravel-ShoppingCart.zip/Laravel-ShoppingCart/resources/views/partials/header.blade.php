<header>
	<div class="head-container">
	<a href="#">Shop all bikes</a>
	<a href="#">Build your own</a>
	</div>
</header>
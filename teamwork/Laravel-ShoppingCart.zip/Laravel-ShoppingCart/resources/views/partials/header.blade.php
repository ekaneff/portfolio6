<header>
  <h2>Leading bike maker since 2003</h2>

  <div>
    <a href="#">Shop all bikes</a>
    <a href="#">Build your own</a>
  </div>
</header>
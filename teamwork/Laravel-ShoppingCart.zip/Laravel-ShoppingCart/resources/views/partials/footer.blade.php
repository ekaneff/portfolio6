<footer>
	<div>Site by Bubbly Duck Design and Development</div>
</footer>
<?php

namespace App;

use App\Order

class Cart
{
	protected $cart = new array();

	public function __construct()
	{
		
	}
}
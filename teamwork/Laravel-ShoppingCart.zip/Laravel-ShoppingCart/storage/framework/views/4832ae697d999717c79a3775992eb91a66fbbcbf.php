<?php $__env->startSection('title'); ?>
	Order Confirmation
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
	<section class="orderpage">
		<h1>Order complete!</h1>
		<p>Thank you for shopping with The Bike Shop! You ordered [product name]. We will send you confirmation when the order ships</p>
		<article class="order">
			<h2>Order Confirmation</h2>
			<h3>Estimated Delivery Date:</h3>
			<h4>Tuesday, Janurary 10th, 2017</h4>
			<h5 class='total'>Order Total: [total here]</h5>
			<p><button class="btn btn-default">Continue Shopping</button></p>
		</article>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
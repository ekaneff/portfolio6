<?php $__env->startSection('title'); ?>
	The Bike Shop | Order History
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<h1>Order History</h1>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title'); ?>
	The Bike Shop | Order History
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<h1>Order History</h1>

<?php for($i = 1; $i <= $count; $i++): ?>
     <div class="row cart">
         <h2>Order #<?php echo e($i); ?></h2>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($order['orderNumber'] == $i): ?>
                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <?php for($f = 0; $f < count($products); $f++): ?>
                            <?php if($products[$f]['id'] == $order['product_id']): ?>
                              <img src="<?php echo e($products[$f]['imgPath']); ?>" class="img-responsive" alt="...">
                              <div class="caption">
                                <h3><a href="#"><?php echo e($products[$f]['name']); ?></a></h3>
                                <div class="clearfix">
                                    <div class="pull-left">
                                    <div class="price">$<?php echo e($products[$f]['price']); ?>.00</div>
                                    <div class="quantity">Quantity: <?php echo e($order['quantity']); ?></div>
                                    </div>
                                </div>
                              </div>
                            <?php endif; ?>
                        <?php endfor; ?> 
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
    </div>
<?php endfor; ?>




<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
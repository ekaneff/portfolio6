<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>
	The Bike Shop | My Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>My Cart</h1>
<div class="container cart">
	
	
	<?php if(count($items) > 0): ?>
	<?php $__currentLoopData = $items->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemChunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<div class="row">
			<?php $__currentLoopData = $itemChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<div class="col-sm-6 col-md-4">
				    <div class="thumbnail">
				      <img src="<?php echo e($item->imgPath); ?>" class="img-responsive" alt="...">
				      <div class="caption">
				        <h3><a href="#"><?php echo e($item->name); ?></a></h3>
				        <p class="desc"><?php echo e($item->description); ?></p>
				        <div class="clearfix">
				        	<div class="pull-left price">$<?php echo e($item->price); ?>.00</div>
				        	<form action="/cart/add" method="post">
					        	<!-- <a href="" class="btn btn-default pull-right" role="button">Add to Cart</a> -->
					        	<input type="hidden" name="item" value="<?php echo e($item->id); ?>">
					        	<input type="submit" name="submit" value="Remove" class="btn btn-default pull-right">					        
					        </form>
					        <a href="" class="pull-right wishlist" role="button">Add to WishList</a>
				        </div>
				      </div>
				    </div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<?php else: ?>
		<h2>Your cart is empty!</h2>
		<h3>It doesn't have to stay that way! Click below to keep shopping</h3>
		<a href="<?php echo e(route('product.index')); ?>" class="btn btn-default" role="button">Continue Shopping</a>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
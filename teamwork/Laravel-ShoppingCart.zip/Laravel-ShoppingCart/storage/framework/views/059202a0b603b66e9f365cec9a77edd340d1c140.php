<?php $__env->startSection('title'); ?>
	Bike Shop
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<section id="featured">
	<h1>Today's Featured</h1>
	<div class="container">
		<?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productChunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<div class="row">
			<?php $__currentLoopData = $productChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<div class="col-sm-6 col-md-4">
				    <div class="thumbnail">
				      <img src="<?php echo e($product->imgPath); ?>" class="img-responsive" alt="...">
				      <div class="caption">
				        <h3><a href="#"><?php echo e($product->name); ?></a></h3>
				        <p class="desc"><?php echo e($product->description); ?></p>
				        <div class="clearfix">
				        	<div class="pull-left price">$<?php echo e($product->price); ?>.00</div>
				        	<form action="/cart/add" method="post" pull-right>
					        	<!-- <a href="" class="btn btn-default pull-right" role="button">Add to Cart</a> -->
					        	<?php echo e(csrf_field()); ?>

					        	<input type="hidden" name="item" value="<?php echo e($product->id); ?>">
					        	<input type="submit" name="submit" value="Add to Cart" class="btn btn-primary pull-right">					        
					        </form>
				        </div>
				      </div>
				    </div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</div> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
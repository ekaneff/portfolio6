<?php $__env->startSection('title'); ?>
	Order Confirmation
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>

	
	<div class="container">
		<h1>Payment Info</h1>
		<form action="/cart/charge" method="POST" id="payment-form">
			<?php echo e(csrf_field()); ?>

			<div class="alert alert-danger payment-errors" role="alert"></div>
		  <div class="form-group">
		    <input type="hidden" class="form-control" id="total" value='$<?php echo e($total); ?>.00' >
		  </div>
		  <div class="form-group">
		    <label for="card-number">Card Number</label>
		    <input type="text" class="form-control card-number" id="card-number" size="20" data-stripe="number">
		  </div>
		  <div class="form-group">
		    <label for="expiration">Expiration</label>
		    <input type="text" class="card-expiry-month" id="expiration" size="2" size="2" data-stripe="exp_month"> 
		    <span> / </span>
		    <input type="text" class="card-expiry-year" id="expiration" size="2" size="2" data-stripe="exp_year">
		  </div>
		  <div class="form-group">
		    <label for="cvc">CVC</label>
		    <input  id="expiration" class="card-cvc" type="text" size="4" data-stripe="cvc">
		  </div>	
		  <h2>Total: $<?php echo e($total); ?>.00</h2>	 
		  <button type="submit" class="btn btn-primary submit">Submit</button>
		</form>
		
	</div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
	<script type="text/javascript">
	  Stripe.setPublishableKey('pk_test_0YlsytUgEhdo3XUOFFnOIgfW');

	  $(function() {
		var $form = $('#payment-form');
		$form.submit(function(event) {
			// Disable the submit button to prevent repeated clicks:
		    $form.find('.submit').prop('disabled', true);

		    // Request a token from Stripe:
		    Stripe.card.createToken($form, stripeResponseHandler);

		    // Prevent the form from being submitted:
		    return false;
		  });
		});

	  	Stripe.card.createToken({
		  number: $('.card-number').val(),
		  cvc: $('.card-cvc').val(),
		  exp_month: $('.card-expiry-month').val(),
		  exp_year: $('.card-expiry-year').val()
		}, stripeResponseHandler);

	  	//Callback
		function stripeResponseHandler(status, response) {
		  // Grab the form:
		  var $form = $('#payment-form');

		  if (response.error) { // Problem!

		    // Show the errors on the form:
		    $form.find('.payment-errors').text(response.error.message);
		    $form.find('.submit').prop('disabled', false); // Re-enable submission

		  } else { // Token was created!

		    // Get the token ID:
		    var token = response.id;

		    // Insert the token ID into the form so it gets submitted to the server:
		    $form.append($('<input type="hidden" name="stripeToken">').val(token));
		    $form.append($('<input type="hidden" name="total">').val(<?php echo e($total); ?>));

		    console.log(token);
		    // Submit the form:
		    $form.get(0).submit();
		  }
		};
	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>